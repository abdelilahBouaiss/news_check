<!DOCTYPE html>
<html <?php language_attributes();?>>
<head>  
    <meta charset="<?php bloginfo('charset');?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5"> 
	<meta 
		name="description"
		content="AGOS est une societé de sécurité et gardiennage à Tanger, spécialisée dans la gestion et la prévention des risques pour assurer la sécurité des biens et la protection des personnes."> 
	<title><?php wp_title('');?> </title> 
	
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@400;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<link rel="shortcut icon" type="image/png" href="<?php echo get_field('Favicon', 'option')['url'] ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <?php wp_head();?> 
</head>



<body <?php body_class();?>>  
	
<header class="fixed-top  " id="top-menu">  
  
<nav class="navbar navbar-expand-lg navbar-light py-0 px-lg-0" role="navigation" id="navigation">
	<div class="container-fluid justify-content-center">
			<div class="col-sm-12  px-lg-0">
				<div class="row align-content-between"> 
					<div class="col-12 align-content-between d-block d-lg-none">
						<div class="row flex-center">    
							<div class="col-3 lang_col">
								<?php  
									wp_nav_menu( array(
										'theme_location'    => 'lang-menu',
										'depth'             => 2,
										'container'         => 'div',
										'container_class'   => '',
										'container_id'      => 'navbarlangSupportedContent',
										'menu_class'        => 'nav navbar-nav langmenu',  
										'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
										'walker'            => new WP_Bootstrap_Navwalker(),
									) );
								?>
							</div>
							<div class="col-6 col-xl-12 pl-3">  
								<a aria-label="Accueil" href="<?php echo pll_home_url() ?>">   
									<img class='main_logo_img main_logo_img_not_scrolled img-fluid' src="<?= get_field('logo','option')['url'] ?>" alt="<?= get_field('logo','option')['alt'] ?>">
									<img class='main_logo_img main_logo_img_scrolled img-fluid' src="<?= get_field('logo_scrolled','option')['url'] ?>" alt="<?= get_field('logo','option')['alt'] ?>"> 
								</a>
							</div> 
							<div class="col-3 p-0 text-right d-flex align-items-center justify-content-end">  
								<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
									<div id="navbarSupportedContent" onclick="toggle_nav()" class="collapse desktop_menu_opn navbar-collapse">      
										<span class="navigation_menu_burger"></span>      
									</div> 
								</button>
							</div>
						</div>
					</div>   
					 

						<div class="col-12  d-none d-lg-block header_nav">
							<div class="row">
								<div class="col-4 lang_col">
								<?php
									wp_nav_menu( array(
										'theme_location'    => 'lang-menu',
										'depth'             => 2,
										'container'         => 'div',
										'container_class'   => '',
										'container_id'      => 'navbarlangSupportedContent',
										'menu_class'        => 'nav navbar-nav langmenu',  
										'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
										'walker'            => new WP_Bootstrap_Navwalker(),
									) );
								?>
								</div>

								<div class="col-4 text-center">  
									<a aria-label="Accueil" href="<?php echo pll_home_url() ?>">      
										<img class='main_logo_img main_logo_img_not_scrolled img-fluid' src="<?= get_field('logo','option')['url'] ?>" alt="<?= get_field('logo','option')['alt'] ?>" data-tilt>
										<img class='main_logo_img main_logo_img_scrolled img-fluid' src="<?= get_field('logo_scrolled','option')['url'] ?>" alt="<?= get_field('logo','option')['alt'] ?>" data-tilt> 
									</a>
								</div> 

								<div class="col-4"> 
									<div id="navbarSupportedContent" class="collapse desktop_menu_opn desktop_menu_opn_2 navbar-collapse open-overlay">      
										<span class="navigation_menu_burger"></span>    
									</div>	  
 
										<!-- <div class="open-overlay" onclick="toggle_nav()">
											<span class="bar-top"></span>
											<span class="bar-middle"></span>
											<span class="bar-bottom"></span>
										</div>  -->
								</div>
							</div> 
						</div>
 
					</div>
				</div>			 
			</div>
	</div>
</nav>
<div id="myNav" class="container-fluid overlay"> 
    <div class="row justify-content-center overlay_content"> 
        <div class="col-lg-6 fullnav_left_bloc">
			<?php
				wp_nav_menu( array(
					'theme_location'    => 'main-menu',
					'depth'             => 2,
					'container'         => '',
					'container_class'   => '', 
					'container_id'      => 'navbarSupportedContent',
					'menu_class'        => 'list-inline d-flex mb-sm-0',
					'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
					'walker'            => new WP_Bootstrap_Navwalker(),
				)); 
			?>								
		</div>
		<div class="col-lg-6 fullnav_right_bloc">
			<div class="row"> 
				<div class="col-12 text-center menu_logo_contain" data-tilt> 
					<img class="img-fluid" src="<?= get_field('logo_menu','option')['url'] ?>" alt="<?= get_field('logo_menu','option')['alt'] ?>" data-tilt>
				</div>
				
				<div class="col-sm-6">
					<h2 class="menu_adresse_title"><?= get_field('traduction', pll_current_language('slug'))['contact']; ?></h2>

					<div class="footer_contact">
						<span><?= get_field('traduction', pll_current_language('slug'))['telephone']; ?>:</span>
						<span><a href="tel:<?= get_field('telephone', 'option'); ?>"><?= get_field('telephone', 'option'); ?></a></span> 
					</div> 
					<div class="footer_contact">  
						<span><?= get_field('traduction', pll_current_language('slug'))['email']; ?>:</span> 
						<span><a href="mailto:<?= get_field('email', 'option'); ?>"><?= get_field('email', 'option'); ?></a></span>  
					</div>
				</div>
				<div class="col-sm-6">
					<h2 class="menu_adresse_title"><?= get_field('traduction', pll_current_language('slug'))['adresse']; ?></h2>
					<div class="footer_adresse">
						<?= get_field('adresse', pll_current_language('slug')); ?>  
					</div>
				</div> 
			</div>
		</div>
    </div>
</div> 

<div class="overlay-navigation">
  <nav role="navigation">
    <div class="full_menu_li_contain"> 
      <div class="full_menu_li full_menu_li_1">
	  	<div class="col-lg-12 fullnav_left_bloc"> 
			<?php
				wp_nav_menu( array(
					'theme_location'    => 'main-menu',
					'depth'             => 2,
					'container'         => '',
					'container_class'   => '', 
					'container_id'      => 'navbarSupportedContent',
					'menu_class'        => 'list-inline d-flex mb-sm-0',
					'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
					'walker'            => new WP_Bootstrap_Navwalker(),
				)); 
			?>								
		</div>
	  </div>
      <div class="full_menu_li full_menu_li_2">
	  	<div class="row">  
			<div class="col-12 text-center menu_logo_contain" data-tilt> 
				<img class="img-fluid" src="<?= get_field('logo_menu','option')['url'] ?>" alt="<?= get_field('logo_menu','option')['alt'] ?>" data-tilt>
			</div>
				
			<div class="col-sm-6">
				<h2 class="menu_adresse_title"><?= get_field('traduction', pll_current_language('slug'))['contact']; ?></h2>

				<div class="footer_contact">
					<span><?= get_field('traduction', pll_current_language('slug'))['telephone']; ?>:</span>
					<span><a href="tel:<?= get_field('telephone', 'option'); ?>"><?= get_field('telephone', 'option'); ?></a></span> 
				</div> 
				<div class="footer_contact">  
					<span><?= get_field('traduction', pll_current_language('slug'))['email']; ?>:</span> 
					<span><a href="mailto:<?= get_field('email', 'option'); ?>"><?= get_field('email', 'option'); ?></a></span>  
				</div>
			</div>
			<div class="col-sm-6">
				<h2 class="menu_adresse_title"><?= get_field('traduction', pll_current_language('slug'))['adresse']; ?></h2>
				<div class="footer_adresse">
					<?= get_field('adresse', pll_current_language('slug')); ?>  
				</div>
			</div> 
		</div>
	  </div> 
	</div>
  </nav>
</div>  
</header>
