<?php
/*
 * Template Name: Search Page
 */
?>

<h1>result</h1>
<?php 


echo do_shortcode('[searchandfilter id="140" show="results"]'); 

 
?>