<?php get_header(); ?> 
<?php 

$post_id = get_the_ID();

?>
<section class="single_service_img"  style="background-image:url('<?= get_the_post_thumbnail_url() ?>')">
    <div class="container">
        <div class="row">
            <div class="col-12">   
                <h1 class="single_service_header_title" data-aos="fade-up" data-aos-duration="1000">  
                    <span class="single_service_header_number"><?= get_field('nombre') ?></span> 
                    <span class="single_service_header_text"><?= get_the_title() ?></span>
                </h1> 
            </div>
        </div>
    </div>
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section>

<section class="single_service_desc_section" data-aos="fade-up" data-aos-duration="2500">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="single_service_desc">
                    <?= get_the_content(); ?>
                </div>
            </div>   
        </div>
    </div>
</section>  

<section class="single_nos_services d-none" data-aos="fade-up" data-aos-duration="2500"> 
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="services_main_title "><?= get_field('traduction', pll_current_language('slug'))['nos_services']; ?></h2>
            </div>
        </div>
        <div class="row single_nos_services_row">
            <?php 
                $args = array(  
                'post_type' => 'service',
                'post_status' => 'publish',
                'posts_per_page' => -1,    
                'order' => 'ASC',   
                );
                $loop = new WP_Query( $args );  
            ?>    
            <?php $i=1; while ( $loop->have_posts() ) : $loop->the_post(); ?>  
                <div class="col-6 col-lg-3 single_service_bloc" style="background-image:url('<?= get_the_post_thumbnail_url() ?>')" > 
                    <a href="<?= get_the_permalink(get_the_id()) ?>" class="single_service_bloc_link"> 
                        <div class="single_service_bloc_number"><?= get_field('nombre') ?></div>
                        <div class="single_service_bloc_text"><?= get_the_title() ?></div>  
                    </a>
                </div>
            <?php $i++; endwhile; wp_reset_postdata(); ?>
        </div>
    </div>
</section>

<?php if($post_id=="542" || $post_id=="545"): ?>
<section class="reservation_form_section">
    <div class="container">
        <div class="row">
            <?php if(pll_current_language() == 'fr'): ?>
            <div class="col-12">
                <?= do_shortcode('[contact-form-7 id="559" title="reservation fr"]') ?> 
            </div>
            <?php endif; ?>

            <?php if(pll_current_language() == 'en'): ?>
            <div class="col-12">  
                <?= do_shortcode('[contact-form-7 id="580" title="reservation en"]') ?> 
            </div>
            <?php endif; ?>
        </div>
    </div> 
</section>
<?php endif; ?>

<?php get_template_part('content','secteur'); ?> 

<?php get_footer(); ?> 
<script>
  let secteur_bg_img = $(".secteur_bg_img").outerWidth();
  $(".secteur_bg_img").css("min-height",secteur_bg_img * 0.5);    

  $('.arrow_link').click(function(){
    $("body,html").animate({ scrollTop: window.pageYOffset + $(window).height()}, 600);
    return false;
  });
</script>

<script>
    //  gallery images
    $(".gallery_bg_img").on({
    mouseenter: function () {   
        $( ".active_gallery" ).removeClass("active_gallery");
        $(this).addClass("active_gallery");
    },
    mouseleave: function () {
        // console.log(this);
    }
    });

    $(window).scroll(function () {       
        $(".single_service_bloc").length && $(".single_service_bloc").bgscroll()   
    });
</script>