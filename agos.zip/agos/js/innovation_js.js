AOS.init();  

$('.blog_sliders').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 2,
  slidesToScroll: 1,      
  arrows: true,
  prevArrow: $('.prev_arrow_2'),  
  nextArrow: $('.next_arrow_2'),
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1
      }
    },   
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
}); 
  
$('.vouiture_slider').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  autoplay: false,
  autoplaySpeed: 100,  
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});

window.onscroll = function() {scrollFunction()};   
function scrollFunction() {  
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 100) { 
    document.querySelector("header").classList.add("scrolled");      
  } else { 
    document.querySelector("header").classList.remove("scrolled");           
  }
} 
  
let d_width = window.innerWidth;
if(d_width >= 1600){   
  let padding = (d_width - 1400) / 2;
  padding = padding + 6;  
  document.querySelector(".overlay_content")&&(document.querySelector(".overlay_content").style.paddingLeft=padding+"px",document.querySelector(".overlay_content").style.paddingRight=padding+"px");
  document.querySelector(".full_menu_li_2")&&(document.querySelector(".full_menu_li_2").style.paddingLeft=padding+"px",document.querySelector(".full_menu_li_2").style.paddingRight=padding+"px");
  document.querySelector(".full_menu_li_1")&&(document.querySelector(".full_menu_li_1").style.paddingLeft=padding+"px"); 
}
if(d_width <= 1600){  
  let padding = (d_width - 1140) / 2;
  document.querySelector(".overlay_content")&&(document.querySelector(".overlay_content").style.paddingLeft=padding+"px",document.querySelector(".overlay_content").style.paddingRight=padding+"px");
  document.querySelector(".full_menu_li_2")&&(document.querySelector(".full_menu_li_2").style.paddingLeft=padding+"px",document.querySelector(".full_menu_li_2").style.paddingRight=padding+"px");
  document.querySelector(".full_menu_li_1")&&(document.querySelector(".full_menu_li_1").style.paddingLeft=padding+"px");
}
function toggle_nav() {
    if ("0%" === document.getElementById("myNav").style.left) {
        (document.getElementById("myNav").style.left = "-100%"),
            (document.getElementById("myNav").style.padding = "0%"),
            document.getElementById("navbarSupportedContent").classList.remove("menu-open"),     
            document.querySelector(".main_logo_img").style.opacity = "1"   
             
    } else { 
        (document.getElementById("myNav").style.left = "0%"),
            (document.getElementById("myNav").style.padding = "18px"),
            document.getElementById("navbarSupportedContent").classList.add("menu-open"),
            document.querySelector(".main_logo_img").style.opacity = "0"
    }
}
 
$('.open-overlay').click(function() {
  var overlay_navigation = $('.overlay-navigation'),
    nav_item_1 = $('nav .full_menu_li:nth-of-type(1)'),
    nav_item_2 = $('nav .full_menu_li:nth-of-type(2)')
    top_bar = $('.bar-top'),
    middle_bar = $('.bar-middle'),
    bottom_bar = $('.bar-bottom');

  overlay_navigation.toggleClass('overlay-active');
  if (overlay_navigation.hasClass('overlay-active')) {

    top_bar.removeClass('animate-out-top-bar').addClass('animate-top-bar');
    middle_bar.removeClass('animate-out-middle-bar').addClass('animate-middle-bar');
    bottom_bar.removeClass('animate-out-bottom-bar').addClass('animate-bottom-bar');
    overlay_navigation.removeClass('overlay-slide-up').addClass('overlay-slide-down')
    nav_item_1.removeClass('slide-in-nav-item-reverse').addClass('slide-in-nav-item');
    nav_item_2.removeClass('slide-in-nav-item-delay-1-reverse').addClass('slide-in-nav-item-delay-1'); 

    document.getElementById("navbarSupportedContent").classList.add("menu-open"); 
    document.querySelector(".desktop_menu_opn_2").classList.add("menu-open"); 
  } else {
    top_bar.removeClass('animate-top-bar').addClass('animate-out-top-bar'); 
    middle_bar.removeClass('animate-middle-bar').addClass('animate-out-middle-bar');
    bottom_bar.removeClass('animate-bottom-bar').addClass('animate-out-bottom-bar');     
    overlay_navigation.removeClass('overlay-slide-down').addClass('overlay-slide-up')
    nav_item_1.removeClass('slide-in-nav-item').addClass('slide-in-nav-item-reverse');
    nav_item_2.removeClass('slide-in-nav-item-delay-1').addClass('slide-in-nav-item-delay-1-reverse'); 

    document.getElementById("navbarSupportedContent").classList.remove("menu-open");  
    document.querySelector(".desktop_menu_opn_2").classList.remove("menu-open"); 
  }
}) 
$(".fullnav_left_bloc .nav-link").hover(
  function () {
      $(window).width() > 500 &&
          ("accueil" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/contemporary-building-exterior-skyscraper-design-concept-2-1-min.jpg')"),
          "Qui sommes-nous" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/about_us.jpg')"),
          "About us" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/about_us.jpg')"),
          "Mot de directeur" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/mot_de_directeur.jpg')"),
          "Founder" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/mot_de_directeur.jpg')"),
          "Nos services" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/services.jpg"),
          "Our services" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/services.jpg"),
          "Recrutement" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/hunters-race-MYbhN8KaaEc-unsplash-min-scaled.jpg"),
          "Recruitment" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/hunters-race-MYbhN8KaaEc-unsplash-min-scaled.jpg"),

          "Contactez-nous" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/burst-kUqqaRjJuw0-unsplash-min-scaled.jpg"),
          "Contact us" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/burst-kUqqaRjJuw0-unsplash-min-scaled.jpg"),
  
          "Devis en ligne" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/corinne-kutz-tMI2_-r5Nfo-unsplash-min-scaled.jpg"),
          "Online quote" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/corinne-kutz-tMI2_-r5Nfo-unsplash-min-scaled.jpg"),

          "Notre blog" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/jack-finnigan-mt3gtjvRp1U-unsplash-min-scaled.jpg"),  
          "Our blog" == $(this).attr("title") && $(".overlay-navigation").css("background-image", "url('/sub/wp-content/uploads/2022/01/jack-finnigan-mt3gtjvRp1U-unsplash-min-scaled.jpg")); 
  },      
  function () {
    $(".overlay-navigation").css("background-image", "unset");   
  }
); 
 

$('.vouiture_slider_2').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  autoplay: true,
  autoplaySpeed: 100,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
 

$('.vouiture_slider_3').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  autoplay: true,
  autoplaySpeed: 100,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
    

$('.vouiture_slider_4').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  autoplay: true,
  autoplaySpeed: 100,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        autoplay: true,
        autoplaySpeed: 1000
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1000
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});

  

$(document).ready(function() {
  $("#lightgallery").lightGallery({
      selector : 'div a',
      thumbnail:true,
      pager: true,
      animateThumb: false,
      showThumbByeDefault: false,
  }); 
});

$(document).ready(function() {
  $("#lightgallery_2").lightGallery({
      selector : 'div a',
      thumbnail:true,
      pager: true,
      animateThumb: false,
      showThumbByeDefault: false,
  }); 
});

$(document).ready(function() {
  $("#lightgallery_3").lightGallery({
      selector : 'div a',
      thumbnail:true,
      pager: true,
      animateThumb: false,
      showThumbByeDefault: false,
  }); 
});

$(document).ready(function() {
  $("#lightgallery_4").lightGallery({
      selector : 'div a',
      thumbnail:true,
      pager: true,
      animateThumb: false,
      showThumbByeDefault: false,
  }); 
});