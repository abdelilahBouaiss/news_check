document.addEventListener("DOMContentLoaded", () => {
       
    anime.timeline({ 
        easing: "easeOutExpo" 
    })
    .add({
        targets: '.lang_col',   
        translateX: [-100, 0],       
        opacity: [0, 1],        
        duration: 2000,
        delay: 300 
    })
    .add({   
        targets: '.slider_side_contain',   
        translateX: [-100, 0],          
        opacity: [0, 1],        
        duration: 1000,
        delay: 300      
    });
     
    document.getElementById("navbarSupportedContent").addEventListener("click", function(){  
        console.log("NAV click");  
        // anime.timeline({ 
        //     easing: "easeOutExpo" 
        // })   
        // .add({    
        //     targets: ".full_menu_li_1 li",   
        //     translateX: [100, 0],
        //     opacity: [0, 1],       
        //     delay: (e, a) => 150 * a,   
        //     offset: "-=100",   
        //     duration: 2000   
        // })   
          
    }); 
});
 