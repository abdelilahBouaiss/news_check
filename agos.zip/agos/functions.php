<?php

 
// chargement des scripts

function innovation_load_scripts(){ 
	$version = '1.0.0';
    // CSS files
    wp_enqueue_style('innovation_bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css', array(), $version, 'all');
	  wp_enqueue_style('innovation_fontawesome', 'https://use.fontawesome.com/releases/v5.8.1/css/all.css', array(), $version, 'all');
	  wp_enqueue_style('innovation_slick-theme', get_template_directory_uri() . '/css/slick-theme.css', array('innovation_bootstrap'), $version, 'all');
	  wp_enqueue_style('innovation_slick', get_template_directory_uri() . '/css/slick.css', array('innovation_bootstrap'), $version, 'all');
	  wp_enqueue_style('innovation_lightgallery','https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.11/css/lightgallery.min.css', array('innovation_bootstrap'), $version, 'all');
	    
	  wp_enqueue_style('innovation_aos', 'https://unpkg.com/aos@2.3.1/dist/aos.css', array('innovation_bootstrap'), $version, 'all');     
	  wp_enqueue_style('innovation_style', get_template_directory_uri() . '/style.css', array('innovation_bootstrap'), $version, 'all');
	  
    // JS Files
    wp_enqueue_script('innovation_jquery', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js', array(), $version, true); 
	
    wp_enqueue_script('innovation_popper_js', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js', array('innovation_jquery'), $version, true);

    wp_enqueue_script('innovation_bootstrap_js', get_template_directory_uri().'/js/bootstrap.min.js', array('innovation_jquery'), $version, true);
	wp_enqueue_script('innovation_slick', get_template_directory_uri() . '/js/slick.js', array('jquery'), $version, true); 
	wp_enqueue_script('innovation_lightgallery', 'https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.11/js/lightgallery-all.min.js', array('jquery'), $version, true);
   
    wp_enqueue_script('innovation_aos', 'https://unpkg.com/aos@2.3.1/dist/aos.js', array('jquery'), $version, true);
  
    wp_enqueue_script('innovation_gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.0/gsap.min.js', array('jquery'), $version, true);
	wp_enqueue_script('innovation_tilt', 'https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js', array('jquery'), $version, true);
	wp_enqueue_script('innovation_tilt', 'https://unpkg.com/tilt.js@1.2.1/dest/tilt.jquery.min.js', array('jquery'), $version, true); 
	wp_enqueue_script('innovation_animejs', 'https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js', array('jquery'), $version, true);
	wp_enqueue_script('bgscroll_js', get_template_directory_uri() . '/js/bgscroll.js', array('jquery'), $version, true);  
	wp_enqueue_script('anime_js', get_template_directory_uri() . '/js/animation.js', array('jquery'), $version, true);
	wp_enqueue_script('dcm_typing_js', get_template_directory_uri() . '/js/jquery.animateTyping.js', array('jquery'), $version, true); 

    wp_enqueue_script('innovation_js', get_template_directory_uri() . '/js/innovation_js.js', array('jquery'), $version, true);
}// fin function innovation_load_scripts
 
// fin function innovation_load_scripts 


// ajouter les scripts au theme

add_action('wp_enqueue_scripts','innovation_load_scripts');




// Désactiver Windows Live Writer

remove_action('wp_head', 'wlwmanifest_link');


// Ajouter le menu au theme

//add_theme_support('menu');

function innovation_setup() {

	

	// Suprimer la version de wordpress 

remove_action('wp_head', 'wp_generator');



// Masquer les erreurs de connexion

add_filter('login_errors',create_function('$a', "return null;"));

  

add_theme_support( 'post-thumbnails' ); 
 
function inno_custom_excerpt_length( $length ) { 
    return 20; 
} 
add_filter( 'excerpt_length', 'inno_custom_excerpt_length', 999 );





require_once('includes/class-wp-bootstrap-navwalker.php');
 
  register_nav_menus(

    array(

    'main-menu' => __( 'Main Menu' ), 
	'footer-menu' => __( 'Footer Menu' ),
	'lang-menu' => __( 'Lang Menu' ),
  
    
    )

  );

}



add_action( 'init', 'innovation_setup' );


 

 
   

/**
 * ACF Options Page
 */

if ( function_exists( 'acf_add_options_page' ) ) {

  
	// Main Theme Settings Page
	$parent = acf_add_options_page( array(
	  'page_title' => 'Theme General Settings',
	  'menu_title' => 'Theme Settings',
	  'redirect'   => 'Theme Settings',
	) );
  
	// 
	// Global Options
	// Same options on all languages. e.g., social profiles links
	// 
  
	acf_add_options_sub_page( array(
	  'page_title' => 'Global Options',
	  'menu_title' => __('Global Options', 'text-domain'),
	  'menu_slug'  => "acf-options",
	  'parent'     => $parent['menu_slug']
	) );
	
	  // 
	  // Language Specific Options
	  // Translatable options specific languages. e.g., social profiles links
	  // 
	  
	  $languages = array('fr','en');
	
	  foreach ( $languages as $lang ) {
		acf_add_options_sub_page( array(
		  'page_title' => 'Options (' . strtoupper( $lang ) . ')',
		  'menu_title' => __('Options (' . strtoupper( $lang ) . ')', 'text-domain'),
		  'menu_slug'  => "options-${lang}",
		  'post_id'    => $lang,
		  'parent'     => $parent['menu_slug']
		) );
	}
  
}

add_filter('loop_shop_columns', 'loop_columns', 999);
		if (!function_exists('loop_columns')) {
			function loop_columns() {
				return 3; // 3 products per row
		}
}

remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );


if(pll_current_language() == 'fr'){ 
	
	function multi_change_translate_text( $translated ) {  
		$text = array(    
			'Drag & Drop Images Here' => "Glissez et déposez vos fichiers ici", 
			'or' => "ou",
			'Browse Files' => "Parcourir les fichiers",
			'Original size' => "Format original", 
			"Accept All" => "Accepter",
			"Reject All" => "Rejeter",
			"cookie_text" => "Nous utilisons des cookies sur notre site Web. Certains d'entre eux sont essentiels, tandis que d'autres nous aident à améliorer ce site Web et votre expérience.",
		);
		$translated = str_ireplace( array_keys( $text ), $text, $translated );
		return $translated;
	}
	add_filter( 'gettext', 'multi_change_translate_text', 20 );
 
}

if(pll_current_language() == 'en'){ 
	
	function multi_change_translate_text_en( $translated ) {    
		
		$text = array(       
			"Accept All" => "Accept",  
			"Reject All" => "Reject",
			"cookie_text" => "We use cookies on our website. Some of them are essential, while others help us to improve this website and your experience.",
		);
		$translated = str_ireplace( array_keys( $text ), $text, $translated );
		return $translated;      
	}
	add_filter( 'gettext', 'multi_change_translate_text_en', 20 );
 
}
// function searchbar( $form ) {

// 	$form = '<form role="search" method=”get” id="searchform" action="' . home_url( '/' ) . '" >
// 	<div><label class="screen-reader-text" for="s">' . __('Search for:') . '</label>
// 	<input type="text" value="' . get_search_query() . '" name="s" id="s" />
// 	<input type="submit" id="searchsubmit" value="'. esc_attr__('Search') .'" />
// 	</div>
// 	</form>';
	
// 	return $form;
// 	} 

// add_shortcode('searchbar', 'searchbar');
 
   
?>