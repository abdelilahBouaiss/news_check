<?php
/*
 * Template Name: About Page
 */
?> 
<?php get_header() ?>
 
<section class="nos_services_header single_service_img" style="background-image:url('<?= get_field('header')['image']['url'] ?>')">
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <h1 class="nos_services_header_main_title" data-aos="fade-up" data-aos-duration="1000"><?= get_field('header')['titre'] ?></h1>
            </div>
        </div> 
    </div> 
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section>


<section class="who_us">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h2 class="about_second_title" data-aos="fade-up" data-aos-duration="1500">
                    <?= get_field('qui_somme-nous')['content_1']['titre'] ?>
                </h2>   
                <div class="about_second_desc" data-aos="fade-up" data-aos-duration="2500">
                    <?= get_field('qui_somme-nous')['content_1']['description'] ?>      
                </div>
            </div>
            <div class="col-lg-6 about_image_bg" style="background-image:url('<?= get_field('qui_somme-nous')['image']['url'] ?>')">
                <div class="about_image_title">  
                    <?= get_field('qui_somme-nous')['image_title'] ?>
                </div>
            </div>
        </div>
        <div class="row">  
            <div class="col-lg-12">
                <h2 class="about_second_title" data-aos="fade-up" data-aos-duration="1500">
                    <?= get_field('qui_somme-nous')['content_3']['titre'] ?>
                </h2>  
                <div class="about_second_desc" data-aos="fade-up" data-aos-duration="2500">
                    <?= get_field('qui_somme-nous')['content_3']['description'] ?>    
                </div>
            </div>
            <div class="col-lg-12">
                <h2 class="about_second_title" data-aos="fade-up" data-aos-duration="1500">
                    <?= get_field('qui_somme-nous')['content_2']['titre'] ?>
                </h2>  
                <div class="about_second_desc" data-aos="fade-up" data-aos-duration="2500">
                    <?= get_field('qui_somme-nous')['content_2']['description'] ?>    
                </div>
            </div> 
        </div>
    </div>
</section>

<section class="engagement" data-aos="fade-up" data-aos-duration="2500">
    <div class="container">
        <div class="row">  
            <div class="col-12">
                <h2 class="engagement_main_title"><?= get_field('engager_agos')['titre'] ?></h2>
            </div>
        </div>
        <div class="row">
            <?php $i=1; foreach( get_field("engager_agos")['blocs'] as $bloc ): ?>
                <div class="col-lg-6 px-sm-2">     
                    <div class="engager_agos_bloc_contain" style="background-image:url('<?= $bloc['image']['url'] ?>')">  
                        <h3 class="engager_agos_bloc_title">
                            <span class="engager_bloc_number">0<?= $i ?></span>
                            <span class="engager_bloc_titre"><?= $bloc['titre'] ?></span> 
                        </h3>   
                        <div class="engager_agos_bloc_desc"><?= $bloc['description'] ?></div>  
                    </div>
                </div>
            <?php $i++; endforeach; ?>
        </div>
    </div>
</section>

<?php get_footer() ?>

<script>
    $(window).scroll(function () {  
        $(".about_image_bg").length && $(".about_image_bg").bgscroll()   
    });
</script>