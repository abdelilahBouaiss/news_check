<?php
/*
 * Template Name: Mot de directeur Page
 */
?> 
<?php get_header() ?>
  
<section class="nos_services_header single_service_img" style="background-image:url('<?= get_field('header')['image']['url'] ?>')">
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <h1 class="nos_services_header_main_title" data-aos="fade-up" data-aos-duration="1000"><?= get_field('header')['titre'] ?></h1>
            </div>
        </div> 
    </div> 
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section>

<section class="fondateur">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 foundateur_left_bloc" data-aos="fade-up" data-aos-duration="2500">
                <h2 class="foundateur_main_title"><?= get_field('mot_de_fondateur')['titre'] ?></h2>
                <div class="foundateur_content"> 
                    <?= get_field('mot_de_fondateur')['description'] ?>  
                </div>  
            </div>
            <div class="col-lg-4" data-aos="fade-up" data-aos-duration="2500" data-aos-delay="800">   
                <div class="foundateur_img_contain">
                    <img class="img-fluid" src="<?= get_field('mot_de_fondateur')['image']['url'] ?>" alt="<?= get_field('mot_de_fondateur')['image']['alt'] ?>">
                    <div class="foundateur_name_contain">Adnane Ajouami</div>
                </div> 
            </div>   
        </div>
    </div>
</section>
 
<section class="services">  
  <div class="container">
    <div class="row">  
      <div class="col-12">     
        <h2 class='services_main_title' data-aos="fade-down" data-aos-duration="2500"><?= get_field('nos_services')['titre'] ?></h2>
        <div class="services_desc" data-aos="fade-up" data-aos-duration="2500"><?= get_field('nos_services')['description'] ?></div>
      </div>
    </div>
  </div>
  <div class="container-fluid px-sm-0">  
    <div class="row">
      <div class="col-12 d-none d-lg-block">  
        <div class="accordion width" id="accordionHorizontalExample">
          <?php 
            $args = array(  
              'post_type' => 'service',
              'post_status' => 'publish',
              'posts_per_page' => -1,    
              'order' => 'ASC',   
            );
            $loop = new WP_Query( $args ); 
            $i = 1;
          ?>
          <?php while ( $loop->have_posts() ) : $loop->the_post(); ?> 
            <div class="card">
              <div class="card-header" data-toggle="collapse" data-target="#collapse_<?= $i ?>" style="background-image:url('<?= get_the_post_thumbnail_url() ?>')">
                <div class="card_header_title">  
                  <?= get_the_title() ?>  
                </div>
                <div class="card_header_number"><?= get_field('nombre') ?></div>
              </div> 

              <div id="collapse_<?= $i ?>" class="service_open_tab collapse <?php if($i == 1){ echo 'show'; } ?>  width" data-parent="#accordionHorizontalExample" style="background-image:url('<?= get_the_post_thumbnail_url() ?>')">
                <div class="card-body">
                  <div class="services_card_titles">
                    <div class="services_open_number"><?= get_field('nombre') ?></div>
                    <div class="services_open_title"><?= get_the_title() ?> </div> 
                  </div>
                  <div class="services_card_desc">
                    <?= get_the_excerpt(); ?>  
                  </div> 
                  <div class="services_card_btn_contain">    
                    <a href="<?= get_the_permalink(get_the_id()) ?>" class="slider_btn">
                      <span><?= get_field('traduction', pll_current_language('slug'))['en_savoir_plus'] ?></span>  
                      <span>
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M1.375 11.0001C1.375 10.8178 1.44743 10.6429 1.57636 10.514C1.7053 10.385 1.88016 10.3126 2.0625 10.3126L18.2779 10.3126L13.9507 5.98686C13.8217 5.85776 13.7491 5.68267 13.7491 5.50011C13.7491 5.31754 13.8217 5.14245 13.9507 5.01336C14.0798 4.88426 14.2549 4.81174 14.4375 4.81174C14.6201 4.81174 14.7952 4.88426 14.9242 5.01336L20.4242 10.5134C20.4883 10.5772 20.5391 10.6531 20.5737 10.7366C20.6084 10.8201 20.6262 10.9097 20.6262 11.0001C20.6262 11.0905 20.6084 11.1801 20.5737 11.2636C20.5391 11.3471 20.4883 11.423 20.4242 11.4869L14.9242 16.9869C14.7952 17.116 14.6201 17.1885 14.4375 17.1885C14.2549 17.1885 14.0798 17.116 13.9508 16.9869C13.8217 16.8578 13.7491 16.6827 13.7491 16.5001C13.7491 16.3175 13.8217 16.1425 13.9508 16.0134L18.2779 11.6876L2.0625 11.6876C1.88016 11.6876 1.7053 11.6152 1.57636 11.4862C1.44743 11.3573 1.375 11.1824 1.375 11.0001Z" fill="white"/>
                        </svg> 
                      </span>
                    </a>
                  </div>
                </div>
              </div> 
            </div>
          <?php $i++; endwhile; wp_reset_postdata(); ?> 
        </div>
      </div>
      <div class="col-12 d-block d-lg-none">
        <div class="accordion" id="accordionExample_2">
          <?php 
            $args = array(  
              'post_type' => 'service',
              'post_status' => 'publish',
              'posts_per_page' => -1,    
              'order' => 'ASC',   
            );
            $loop = new WP_Query( $args ); 
            $j = 1;
          ?> 
          <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>  
          <div class="card">
            <div class="card-header"data-toggle="collapse" data-target="#collapse_mobile_<?= $j ?>" style="background-image:url('<?= get_the_post_thumbnail_url() ?>')">
              <div class="card_mobile_header_number"><?= get_field('nombre') ?></div>
              <div class="card_mobile_header_title">     
                <?= get_the_title() ?>  
              </div>   
            </div>

            <div id="collapse_mobile_<?= $j ?>" class="collapse_mobile collapse <?php if($j == 1){ echo 'show'; } ?>" aria-labelledby="heading_<?= $j ?>" data-parent="#accordionExample_2" style="background-image:url('<?= get_the_post_thumbnail_url() ?>')">
              <div class="card-body">
                <div class="services_card_titles">
                  <div class="services_open_number"><?= get_field('nombre') ?></div>
                  <div class="services_open_title"><?= get_the_title() ?> </div> 
                </div>

                <div class="services_card_desc">
                  <?= get_the_excerpt(); ?>  
                </div> 
                <div class="services_card_btn_contain">    
                  <a href="<?= get_the_permalink(get_the_id()) ?>" class="slider_btn">
                    <span><?= get_field('traduction', pll_current_language('slug'))['en_savoir_plus'] ?></span>  
                    <span>
                      <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1.375 11.0001C1.375 10.8178 1.44743 10.6429 1.57636 10.514C1.7053 10.385 1.88016 10.3126 2.0625 10.3126L18.2779 10.3126L13.9507 5.98686C13.8217 5.85776 13.7491 5.68267 13.7491 5.50011C13.7491 5.31754 13.8217 5.14245 13.9507 5.01336C14.0798 4.88426 14.2549 4.81174 14.4375 4.81174C14.6201 4.81174 14.7952 4.88426 14.9242 5.01336L20.4242 10.5134C20.4883 10.5772 20.5391 10.6531 20.5737 10.7366C20.6084 10.8201 20.6262 10.9097 20.6262 11.0001C20.6262 11.0905 20.6084 11.1801 20.5737 11.2636C20.5391 11.3471 20.4883 11.423 20.4242 11.4869L14.9242 16.9869C14.7952 17.116 14.6201 17.1885 14.4375 17.1885C14.2549 17.1885 14.0798 17.116 13.9508 16.9869C13.8217 16.8578 13.7491 16.6827 13.7491 16.5001C13.7491 16.3175 13.8217 16.1425 13.9508 16.0134L18.2779 11.6876L2.0625 11.6876C1.88016 11.6876 1.7053 11.6152 1.57636 11.4862C1.44743 11.3573 1.375 11.1824 1.375 11.0001Z" fill="white"/>
                      </svg> 
                    </span>
                  </a> 
                </div>
              </div>
            </div>
          </div>
          <?php $j++; endwhile; wp_reset_postdata(); ?> 
        </div>
      </div>  
    </div>
  </div>
</section> 

<?php get_footer() ?>

<script>
// accodion 
const horizontalAccordions=$(".accordion.width");horizontalAccordions.each((o,a)=>{const c=$(a),d=c.find(".collapse"),i=d.find("> *");c.height(c.height()),i.width(i.eq(0).width()),d.not(".show").each((o,a)=>{$(a).parent().find("[data-toggle='collapse']").addClass("collapsed")})});
</script>