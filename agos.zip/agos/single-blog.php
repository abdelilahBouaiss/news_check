<?php get_header();?>

<section class="nos_services_header single_service_img" style="background-image:url('<?= get_the_post_thumbnail_url() ?>')">
    <div class="container">  
        <div class="row">
            <div class="col-12"> 
                <h1 class="nos_services_header_main_title" data-aos="fade-up" data-aos-duration="1000"><?= get_the_title() ?></h1>  
                <div class="single_blog_date">      
                    <div class="single_blog_day"><?= get_the_date('d') ?></div> 
                    <div class="single_blog_month"><?php echo mb_substr(get_the_date('M'), 0, 3); ?></div>     
                </div>
            </div>
        </div> 
    </div> 
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section> 

<section class="detail_blog">
    <div class="container">
        <div class="row"> 
            <div class="col-12"> 
                <?= get_the_content(); ?> 
            </div>   
        </div>
    </div>
</section>   

  
<?php get_template_part('content','blog'); ?>   
  
<?php get_footer();?>