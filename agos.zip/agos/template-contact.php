<?php
/*
 * Template Name: Contact Page
 */
?>

<?php get_header() ?>

<section class="nos_services_header single_service_img" style="background-image:url('<?= get_field('header')['image']['url'] ?>')">
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <h1 class="nos_services_header_main_title" data-aos="fade-up" data-aos-duration="1000"><?= get_field('header')['titre'] ?></h1>
            </div>
        </div> 
    </div> 
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section>
 
<section class="req_top_header" data-aos="fade-up" data-aos-duration="2500">
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <h2 class="req_top_header_main_title"><?= get_field('second_header')['titre'] ?></h2> 
            </div> 
        </div>
    </div>
</section>
  

<section class="contact_section" data-aos="fade-up" data-aos-duration="2500">
    <div class="container">
        <div class="row">
            <?php 
                $form = get_field('contact', pll_current_language('slug'));            
            ?> 
            <?php echo do_shortcode('[contact-form-7 id="'.$form->ID.'"]') ?>
        </div>
    </div>
</section>
 
<section class="contact_infos">
    <div class="container">
        <div class="row">
            <div class="col-sm-4 contact_infos_col"> 
                <div class="contact_infos_col_icon">
                    <svg width="28" height="32" viewBox="0 0 28 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5.89925 19.2094C5.93169 19.2616 5.96413 19.3007 5.99658 19.3399C6.02902 19.392 6.06146 19.4312 6.0939 19.4833C12.1121 27.9358 22.51 32.9056 24.4403 30.3098L26.8736 26.5923C27.0682 26.2793 27.0358 25.8879 26.7924 25.5227C26.7924 25.5227 26.7762 25.5097 26.76 25.4966C26.4194 24.9618 26.1111 24.9488 24.3268 23.9966C23.4022 23.4357 22.4289 22.8356 21.7638 22.3791C21.1312 21.9356 20.239 21.9095 19.7199 22.3139L18.7142 23.1096C18.3735 23.3835 17.9031 23.527 17.4165 23.527C15.9728 23.5139 13.2151 20.3703 11.6741 18.4398C11.2361 17.892 10.8954 17.4354 10.7008 17.1485C10.5061 16.8745 10.1817 16.3919 9.80861 15.818C8.5109 13.7701 6.5481 10.2743 7.26185 9.26989C7.52139 8.94379 7.92693 8.69596 8.38113 8.5916L9.74373 8.30464C10.4412 8.14811 10.863 7.50895 10.7008 6.85675C10.5548 6.16542 10.3926 5.18712 10.2628 4.261C10.1493 2.55224 10.279 2.31744 9.88972 1.82177C9.88972 1.80873 9.88972 1.79568 9.8735 1.79568C9.61395 1.4435 9.22464 1.22175 8.77044 1.19566L3.56336 1C-0.216233 1.02609 -0.118904 10.7569 5.89925 19.2094Z" stroke="#071142" stroke-width="2" stroke-miterlimit="10"/>
                    </svg> 
                </div> 
                <div class="">  
                    <h3 class="top_header_small_titles"><?= get_field('second_header')['tel_text'] ?></h3>    
                    <a class="top_header_links" href="tel:<?= get_field('telephone', 'option'); ?>"><?= get_field('telephone', 'option'); ?></a>
                </div> 
            </div> 
            <div class="col-sm-4 contact_infos_col">
                <div class="contact_infos_col_icon">  
                    <svg width="37" height="32" viewBox="0 0 37 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M36 9.96812H37C37 9.59662 36.7941 9.25574 36.4652 9.08292L36 9.96812ZM1 9.96812L0.534803 9.08292C0.205947 9.25574 0 9.59662 0 9.96812H1ZM19.2913 1.18732L19.7565 0.302064L19.7477 0.297522L19.2913 1.18732ZM17.7087 1.18732L17.2523 0.297478L17.2435 0.302108L17.7087 1.18732ZM17.5565 21.1676L16.9962 21.9959L16.9988 21.9977L17.5565 21.1676ZM19.4283 21.1676L19.9859 21.9977L19.9882 21.9961L19.4283 21.1676ZM35 9.96812V29.6855H37V9.96812H35ZM35 29.6855C35 29.7167 34.9871 29.7812 34.8993 29.8571C34.8099 29.9343 34.6632 30 34.4783 30V32C35.7251 32 37 31.0932 37 29.6855H35ZM34.4783 30H2.52174V32H34.4783V30ZM2.52174 30C2.33684 30 2.19005 29.9343 2.10071 29.8571C2.01288 29.7812 2 29.7167 2 29.6855H0C0 31.0932 1.27493 32 2.52174 32V30ZM2 29.6855V9.96812H0V29.6855H2ZM36.4652 9.08292L19.7565 0.302108L18.8261 2.07252L35.5348 10.8533L36.4652 9.08292ZM19.7477 0.297522C18.9742 -0.0991739 18.0258 -0.0991739 17.2523 0.297522L18.1651 2.07711C18.3655 1.9743 18.6345 1.9743 18.8349 2.07711L19.7477 0.297522ZM17.2435 0.302108L0.534803 9.08292L1.4652 10.8533L18.1739 2.07252L17.2435 0.302108ZM0.439709 10.7964L16.9962 21.9959L18.1168 20.3393L1.56029 9.13983L0.439709 10.7964ZM16.9988 21.9977C17.8839 22.5923 19.1009 22.5923 19.9859 21.9977L18.8706 20.3375C18.66 20.479 18.3248 20.479 18.1142 20.3375L16.9988 21.9977ZM19.9882 21.9961L36.5599 10.7967L35.4401 9.13959L18.8683 20.3391L19.9882 21.9961Z" fill="#071142"/>
                    </svg> 
                </div> 
                <div class="">  
                    <h3 class="top_header_small_titles"><?= get_field('second_header')['mail_text'] ?></h3>    
                    <a class="top_header_links" href="mailto:<?= get_field('email', 'option'); ?>"><?= get_field('email', 'option'); ?></a>
                </div> 
            </div>  
            <div class="col-sm-4 contact_infos_col">  
                <div class="contact_infos_col_icon"> 
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17 6.45455C17 5.90226 16.5523 5.45455 16 5.45455C15.4477 5.45455 15 5.90226 15 6.45455H17ZM16 16H15C15 16.2652 15.1054 16.5196 15.2929 16.7071L16 16ZM22.1111 23.5253C22.5016 23.9158 23.1348 23.9158 23.5253 23.5253C23.9158 23.1348 23.9158 22.5016 23.5253 22.1111L22.1111 23.5253ZM30 16C30 23.732 23.732 30 16 30V32C24.8366 32 32 24.8366 32 16H30ZM16 30C8.26801 30 2 23.732 2 16H0C0 24.8366 7.16344 32 16 32V30ZM2 16C2 8.26801 8.26801 2 16 2V0C7.16344 0 0 7.16344 0 16H2ZM16 2C23.732 2 30 8.26801 30 16H32C32 7.16344 24.8366 0 16 0V2ZM15 6.45455V16H17V6.45455H15ZM23.5253 22.1111L16.7071 15.2929L15.2929 16.7071L22.1111 23.5253L23.5253 22.1111Z" fill="#071142"/>
                    </svg>
                </div> 
                <div class="">  
                    <h3 class="top_header_small_titles"><?= get_field('second_header')['horaires_text'] ?></h3>    
                    <div class="top_header_hours"> 
                        <?= get_field('second_header')['horaires'] ?>
                    </div>
                </div> 
            </div> 
        </div>
    </div>
</section>
   
<?php get_footer() ?>