<?php
/*
 * Template Name: exemple Page
 */ 
?> 
<?php get_header() ?>

<?php
    if( have_rows('content') ): 
        while ( have_rows('content') ) : the_row();
            if( get_row_layout() == 'header' ):
                ?>
                <section class="header" style="background-image:url('<?= get_sub_field('background_image')['url'] ?>')">
                    <div class="container"> 
                        <div class="row">
                            <div class="col-12">
                                <h2 class="header_title"><?= get_sub_field('titre'); ?></h2>
                                <div class="header_desc"><?= get_sub_field('sous_titre'); ?></div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            endif;
        endwhile;
    endif;
?>


<section class="pages_blog_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="blog_content white_box_content">
                    <h2 class="blog_left_title"><?= get_field('white_box')['title'] ?></h2>
                    <div class="blog_left_description">   
                        <?= get_field('white_box')['description'] ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 single_deal_left_bloc">
                <div class="row">
                    <?php 
                    $currentPage = get_query_var('paged');
                    $args = array(  
                        'post_type' => 'jourel',
                        'post_status' => 'publish',  
                        'posts_per_page'   => 10, 
                        'paged' => $currentPage,  
                    );

                    $loop = new WP_Query( $args ); 
                        
                    while ( $loop->have_posts() ) : $loop->the_post();  
                        ?>   
                            <div class="col-lg-6 px-3 px-lg-2 blogs_item"> 
                                <a href="<?php echo get_the_permalink(get_the_id()) ?>"> 
                                    <div class="blog_bloc" style="background-image:url('<?= get_the_post_thumbnail_url(); ?>')">
                                        <div class="blog_infos"> 
                                            <div class="blog_date">   
                                                <div class="blog_day"><?= get_the_date('d') ?></div> 
                                                <div class="blog_month"><?php echo mb_substr(get_the_date('M'), 0, 3); ?></div>     
                                            </div> 
                                            <!-- substr(get_the_date('M'), 0, 5) -->
                                            <div class="blog_title">
                                                <?= get_the_title(); ?>
                                            </div>
                                        </div>

                                        <div class="deals_zoom_btn">
                                            <svg width="34" height="33" viewBox="0 0 34 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M21.5987 18.1834L19.2585 20.1712C18.5382 20.7833 18.4652 21.8465 19.0959 22.5456C19.4378 22.9258 19.9191 23.1191 20.4004 23.1191C20.8054 23.1191 21.2136 22.9805 21.5422 22.7035L27.3511 17.7646C27.3644 17.7549 27.3743 17.7388 27.3876 17.7259C27.4407 17.6776 27.4872 17.626 27.5337 17.5713C27.5635 17.5391 27.5934 17.5068 27.62 17.4714C27.6664 17.4102 27.7029 17.3425 27.7361 17.2781C27.756 17.2427 27.776 17.2137 27.7926 17.1782C27.8291 17.0977 27.8523 17.0139 27.8755 16.9301C27.8822 16.9044 27.8955 16.8786 27.9021 16.8496C27.9253 16.7368 27.9419 16.6209 27.9419 16.4984C27.9419 16.3792 27.9287 16.26 27.9021 16.1473C27.8955 16.1215 27.8855 16.0957 27.8755 16.0667C27.8523 15.983 27.8258 15.8992 27.7926 15.8187C27.776 15.7832 27.756 15.751 27.7361 15.7188C27.6996 15.6511 27.6631 15.5867 27.62 15.5255C27.5934 15.49 27.5635 15.4578 27.5337 15.4256C27.4872 15.3708 27.4407 15.3193 27.3876 15.271C27.3743 15.2581 27.3644 15.2452 27.3511 15.2323L21.5422 10.2966C20.8219 9.68452 19.7266 9.7554 19.0959 10.4545C18.4652 11.1536 18.5382 12.2168 19.2585 12.8289L21.5987 14.8167H7.79022C6.83425 14.8167 6.05753 15.5706 6.05753 16.4984C6.05753 17.4263 6.83425 18.1802 7.79022 18.1802H21.5987V18.1834Z" fill="white"/>
                                                <path d="M16.9983 33C26.3722 33 33.9967 25.5997 33.9967 16.5016C33.9967 7.4035 26.3722 0 16.9983 0C7.62452 0 0 7.40027 0 16.4984C0 25.5965 7.62452 33 16.9983 33ZM16.9983 2.65791C24.8619 2.65791 31.2582 8.86615 31.2582 16.4984C31.2582 24.1306 24.8619 30.3389 16.9983 30.3389C9.13482 30.3389 2.73846 24.1306 2.73846 16.4984C2.73846 8.86615 9.13482 2.65791 16.9983 2.65791Z" fill="white"/>
                                            </svg> 
                                        </div> 
                                    </div> 
                                </a>
                            </div>
                        <?php
                    endwhile; 
                    wp_reset_postdata(); 
                    ?>
                     
                </div>
            </div>
            <div class="col-sm-12 deals_pagination_container">  
                     
                <?php
                echo "<div class='deals_pagination'>" . paginate_links(array(
                    'total' => $loop->max_num_pages,    
                    'prev_text' => __('<svg width="27" height="19" viewBox="0 0 27 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M26.1877 9.5C26.1877 9.24307 26.0922 8.99667 25.9222 8.81499C25.7523 8.63332 25.5218 8.53125 25.2814 8.53125H3.90659L9.61053 2.43588C9.7807 2.25397 9.8763 2.00726 9.8763 1.75C9.8763 1.49275 9.7807 1.24603 9.61053 1.06413C9.44036 0.882222 9.20956 0.780029 8.9689 0.780029C8.72825 0.780029 8.49745 0.882222 8.32728 1.06413L1.07728 8.81413C0.992884 8.90412 0.925924 9.01102 0.880238 9.12871C0.834551 9.24641 0.811035 9.37258 0.811035 9.5C0.811035 9.62743 0.834551 9.7536 0.880238 9.87129C0.925924 9.98899 0.992884 10.0959 1.07728 10.1859L8.32728 17.9359C8.49745 18.1178 8.72825 18.22 8.9689 18.22C9.20956 18.22 9.44036 18.1178 9.61053 17.9359C9.7807 17.754 9.8763 17.5073 9.8763 17.25C9.8763 16.9928 9.7807 16.746 9.61053 16.5641L3.90659 10.4688H25.2814C25.5218 10.4688 25.7523 10.3667 25.9222 10.185C26.0922 10.0033 26.1877 9.75693 26.1877 9.5Z" fill="black"></path>
                                        </svg>'),
                    'next_text' => __('<svg width="27" height="17" viewBox="0 0 27 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M0.8125 8.49992C0.8125 8.25957 0.90798 8.02906 1.07793 7.85911C1.24789 7.68915 1.4784 7.59367 1.71875 7.59367H23.0936L17.3896 1.89155C17.2195 1.72138 17.1239 1.49058 17.1239 1.24992C17.1239 1.00927 17.2195 0.778468 17.3896 0.608299C17.5598 0.438129 17.7906 0.342529 18.0312 0.342529C18.2719 0.342529 18.5027 0.438129 18.6729 0.608299L25.9229 7.8583C26.0073 7.94248 26.0742 8.04249 26.1199 8.15259C26.1656 8.26269 26.1891 8.38072 26.1891 8.49992C26.1891 8.61913 26.1656 8.73716 26.1199 8.84726C26.0742 8.95736 26.0073 9.05737 25.9229 9.14155L18.6729 16.3915C18.5027 16.5617 18.2719 16.6573 18.0312 16.6573C17.7906 16.6573 17.5598 16.5617 17.3896 16.3915C17.2195 16.2214 17.1239 15.9906 17.1239 15.7499C17.1239 15.5093 17.2195 15.2785 17.3896 15.1083L23.0936 9.40617H1.71875C1.4784 9.40617 1.24789 9.31069 1.07793 9.14074C0.90798 8.97079 0.8125 8.74028 0.8125 8.49992Z" fill="black"></path>
                                        </svg>')
                )) . "</div>";   
                ?>  
                       
            </div>  
        </div>
    </div>
</section>

<?php get_template_part('content','sidebar'); ?>
<?php get_footer() ?> 

<script> 
    $(document).ready(function() {  
        $("a[title='blog']").addClass( "active" );
    });  
</script>