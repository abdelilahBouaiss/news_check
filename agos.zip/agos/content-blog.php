<section class="blog_section" id="blog" data-aos="fade-up" data-aos-duration="2000">
    <div class="container">
        <div class="row">  
            <div class="col-12">   
                <h2 class="blog_main_title"><?= get_field('traduction', pll_current_language('slug'))['derniers_blogs']; ?></h2>
            </div>
            <div class="col-lg-12">
                <div class="row blog_sliders">
                    <?php 
                    $args = array(  
                        'post_type' => 'blog',
                        'post_status' => 'publish',  
                        'posts_per_page' => -1,  
                    );

                    $loop = new WP_Query( $args ); 
                        
                    while ( $loop->have_posts() ) : $loop->the_post();  
                        ?>   
                            <div class="px-3 px-lg-2"> 
                                <a href="<?php echo get_the_permalink(get_the_id()) ?>"> 
                                    <div class="blog_bloc" style="background-image:url('<?= get_the_post_thumbnail_url(); ?>')">
                                        <div class="blog_infos"> 
                                            <div class="blog_date">   
                                                <div class="blog_day"><?= get_the_date('d') ?></div> 
                                                <div class="blog_month"><?php echo mb_substr(get_the_date('M'), 0, 3); ?></div>     
                                            </div> 
                                            <!-- substr(get_the_date('M'), 0, 5) -->
                                            <div class="blog_title">
                                                <?= get_the_title(); ?>
                                            </div>
                                        </div>

                                        <!-- <div class="deals_zoom_btn">
                                            <svg width="34" height="33" viewBox="0 0 34 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M21.5987 18.1834L19.2585 20.1712C18.5382 20.7833 18.4652 21.8465 19.0959 22.5456C19.4378 22.9258 19.9191 23.1191 20.4004 23.1191C20.8054 23.1191 21.2136 22.9805 21.5422 22.7035L27.3511 17.7646C27.3644 17.7549 27.3743 17.7388 27.3876 17.7259C27.4407 17.6776 27.4872 17.626 27.5337 17.5713C27.5635 17.5391 27.5934 17.5068 27.62 17.4714C27.6664 17.4102 27.7029 17.3425 27.7361 17.2781C27.756 17.2427 27.776 17.2137 27.7926 17.1782C27.8291 17.0977 27.8523 17.0139 27.8755 16.9301C27.8822 16.9044 27.8955 16.8786 27.9021 16.8496C27.9253 16.7368 27.9419 16.6209 27.9419 16.4984C27.9419 16.3792 27.9287 16.26 27.9021 16.1473C27.8955 16.1215 27.8855 16.0957 27.8755 16.0667C27.8523 15.983 27.8258 15.8992 27.7926 15.8187C27.776 15.7832 27.756 15.751 27.7361 15.7188C27.6996 15.6511 27.6631 15.5867 27.62 15.5255C27.5934 15.49 27.5635 15.4578 27.5337 15.4256C27.4872 15.3708 27.4407 15.3193 27.3876 15.271C27.3743 15.2581 27.3644 15.2452 27.3511 15.2323L21.5422 10.2966C20.8219 9.68452 19.7266 9.7554 19.0959 10.4545C18.4652 11.1536 18.5382 12.2168 19.2585 12.8289L21.5987 14.8167H7.79022C6.83425 14.8167 6.05753 15.5706 6.05753 16.4984C6.05753 17.4263 6.83425 18.1802 7.79022 18.1802H21.5987V18.1834Z" fill="#F9B233"/>
                                                <path d="M16.9983 33C26.3722 33 33.9967 25.5997 33.9967 16.5016C33.9967 7.4035 26.3722 0 16.9983 0C7.62452 0 0 7.40027 0 16.4984C0 25.5965 7.62452 33 16.9983 33ZM16.9983 2.65791C24.8619 2.65791 31.2582 8.86615 31.2582 16.4984C31.2582 24.1306 24.8619 30.3389 16.9983 30.3389C9.13482 30.3389 2.73846 24.1306 2.73846 16.4984C2.73846 8.86615 9.13482 2.65791 16.9983 2.65791Z" fill="#F9B233"/>
                                            </svg> 
                                        </div>  -->
                                    </div> 
                                </a>
                            </div>
                        <?php
                    endwhile; 
                    wp_reset_postdata(); 
                    ?>
                </div> 
                <div class="d-block d-lg-none text-center">
                    <div class="confiance_arrows blog_arrows"> 
                        <span class="prev_arrow_2 slick-arrow next_arrow_blog" aria-disabled="false" style="">
                            <svg width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L1 10M1 10L10 19M1 10H24" stroke="#163567" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </span>      

                        <span class="next_arrow_2 slick-arrow prev_arrow_blog slick-disabled" aria-disabled="true" style="">
                            <svg width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 1L24 10M24 10L15 19M24 10H1" stroke="#163567" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>     
                        </span>  
                    </div>        
                </div>
            </div>
            <div class="col-lg-12 text-center">    
                <div class="d-none d-lg-block">
                    <div class="confiance_arrows">  
                        <span class="prev_arrow_2 slick-arrow slick-disabled" aria-disabled="true" style=""> 
                            <svg width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L1 10M1 10L10 19M1 10H24" stroke="#163567" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>   
                        </span>  
                        <span class="next_arrow_2 slick-arrow" aria-disabled="false" style="">
                            <svg width="25" height="20" viewBox="0 0 25 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 1L24 10M24 10L15 19M24 10H1" stroke="#163567" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>   
                        </span> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>