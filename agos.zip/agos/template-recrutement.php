<?php
/*
 * Template Name: Recrutement Page
 */
?>

<?php get_header() ?>

<section class="nos_services_header single_service_img" style="background-image:url('<?= get_field('header')['image']['url'] ?>')">
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <h1 class="nos_services_header_main_title" data-aos="fade-up" data-aos-duration="1000"><?= get_field('header')['titre'] ?></h1>
            </div>
        </div> 
    </div> 
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section>

<section class="req_top_header" >
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <div class="req_top_header_desc" data-aos="fade-up" data-aos-duration="2500">
                    <?= get_field('top_description') ?>
                </div> 
            </div>
        </div>
    </div>
</section>

<section class="req_section" data-aos="fade-up" data-aos-duration="2500"> 
    <div class="container">
        <div class="row">
            <?php 
                $form = get_field('recrutement', pll_current_language('slug'));            
            ?> 
            <?php echo do_shortcode('[contact-form-7 id="'.$form->ID.'"]') ?>
        </div>
    </div>
</section>

<?php get_footer() ?>