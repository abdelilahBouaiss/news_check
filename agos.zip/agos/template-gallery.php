<?php
/*
 * Template Name: Gallery Page
 */
?> 
<?php get_header() ?>

<section class="nos_services_header single_service_img" style="background-image:url('<?= get_field('header')['image']['url'] ?>')">
    <div class="container">
        <div class="row">
            <div class="col-12"> 
                <h1 class="nos_services_header_main_title" data-aos="fade-up" data-aos-duration="1000"><?= get_field('header')['titre'] ?></h1>
            </div>
        </div> 
    </div> 
    <?= do_shortcode('[particleground bgcolor= "#16a08500" dotcolor= "#ffffff24" linecolor= "#ffffff24"] [/particleground]'); ?>
</section>

<section class="full_gallery_section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?= do_shortcode("[mwrp_gallery id='414']") ?>     
            </div>
        </div>
    </div>
</section>

<?php get_footer() ?>